num = int(input("digite um número para que calculemos a sua tabuada do 1 ao 10: "))

for i in range(1,11):
    print(num*i)