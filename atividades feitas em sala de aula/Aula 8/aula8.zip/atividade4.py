for i in range(1,101):
    if i<= 50:
        print(i)
    if i> 50 and i % 2 == 0:
        print(i)