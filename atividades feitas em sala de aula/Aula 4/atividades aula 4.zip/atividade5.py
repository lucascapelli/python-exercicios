numero = int(input("digite um valor entre 0 e 9: "))

if numero >= 0 and numero <= 9:
    print("valor correto")
else:
    print("valor incorreto")