divisor = int(input("digite um divisor: "))
dividendo = int(input("digite um dividendo: "))

resultado = int(dividendo / divisor)

print("o resultado da divisão do dividendo", dividendo ,"pelo divisor", divisor ,"é", resultado)