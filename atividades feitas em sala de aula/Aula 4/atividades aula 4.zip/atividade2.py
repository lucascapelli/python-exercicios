altura = float(input("digite o tamanho da altura do triangulo: "))
base = float(input("digite o tamanho da base do triangulo: "))
area = (base * altura) / 2

print("a área do triangulo é de:", area)
