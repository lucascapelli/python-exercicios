celsius= float(input("digite quantos graus celsius estão fazendo hoje: "))
Kelvin = celsius + 273
Fahrenheit = 1.8 * celsius + 32

print("na escala kelvin isso seria", Kelvin ," e na escala Fahrenheit isso seria ", Fahrenheit)
input()