h = float(input("digite o valor em horas: "))
m = h * 60

print("O valor em minutos é:", m)
input()
