print("Ciências da Computação -Unicsu")
input()