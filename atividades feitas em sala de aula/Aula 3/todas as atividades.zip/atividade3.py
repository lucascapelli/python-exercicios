conta = float(input("digite o valor da conta: "))
servico = conta * 0.10
total = servico + conta

print("o valor de sua conta foi", conta ,"a porcentagem de serviço foi", servico ,"e to total foi", total )
input()