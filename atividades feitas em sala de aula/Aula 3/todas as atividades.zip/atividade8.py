anos = int(input("digite sua idade: "))
meses = int(input("quantos meses: "))
dias = int(input("quantos dias: "))

total = ((anos * 365) + (meses * 30)) + dias

print("você tem ", total ," de idade")
input()