print("olá digite seu nome ")
nome = input()

print("agora digite sua idade ")
idade = input()

print("e digite sua profissão ")
profissao = input()

print("seu nome é", nome , " sua idade é", idade , " e sua profissão é" , profissao)

input()